#!/usr/bin/env bash
git pull origin master
